const axios = require("axios");
const cheerio = require("cheerio");
const url = "https://www.trendyol.com/erkek+ceket";
const baseURL = "https://www.trendyol.com";

async function getProduct(prodURL, link) {
  try {
   const response = await axios.get(prodURL);
   const productsDetails = [];
   const html = response.data;
   const $ = cheerio.load(html);
   const product_source = "Trendyol";
   const group_url = link;
   const colors = [];
   const sizes = [];
   const images = [];
   const brand = cheerio(".pr-new-br", html).contents().first().text();
   const name = cheerio(".pr-new-br span", html).text();
   const strorjprice = cheerio(".pr-bx-nm .prc-org", html).first().text();
   const strprice = cheerio(".prc-dsc", html).first().text();
   const price = strprice.split('.').join("");
   const orjprice = strorjprice.split('.').join("");
   const old_description = cheerio(".pr-in-dt-cn span", html).text();
   const new_description = cheerio(".detail-desc-list", html).text();
   const description = old_description ? old_description : new_description;
   const Variants = $('script:contains("allVariants")').html();
   const VariantsTag = Variants.match(/"allVariants":\[(.*?)\]/i)[1];
   const VariantsTagJson = "[" + VariantsTag + "]";
   const VariantsTagParsed = JSON.parse(VariantsTagJson);
   $(VariantsTagParsed).each(function (i, elm) {
     if(elm["inStock"] == true) {
       sizes.push(elm["value"]);
     }
     
   });
   
   const propiteam = cheerio(".prop-item", html).text();
   const PID = $('script:contains("productGroup")').html();
   var value = PID.match(/"productGroupId":(\d+)/i)[1];
   const imageUrls = PID.match(/"images":\[(.*?)\]/g);
   const imageUrl_extract = imageUrls.toString().match(/\[(.*?)\]/g);
   const imageUrl_array = JSON.parse(imageUrl_extract);
   
   $(imageUrl_array).each(function(key,img){
     images.push("https://cdn.dsmcdn.com/" + img);
   });

   const productsAttrebuites = await axios.get(
     "https://public.trendyol.com/discovery-web-productgw-service/api/productGroup/" +
       value
   );
   if (productsAttrebuites.data.result.slicingAttributes[0]) {
     color = productsAttrebuites.data.result.slicingAttributes[0].attributes;
     $(color).each(function (i, elm) {
       colors.push(elm["name"]);
     });
   } else {
     colors.push("No Colors Available");
   }
   productsDetails.push({
     name,
     orjprice,
     price,
     images,
     prodURL,
     sizes,
   });

    return productsDetails;
  } catch (error) {
    console.log(error);
    productsDetails = [];
    return productsDetails;
  }
}

async function getProductsData(link, urls = []) {
  try {
    console.log("Requesting : " + link);
    const productUrl = link;
    urls.push(productUrl);

    return Promise.all(urls.map((url) => getProduct(url, link)));
  } catch (error) {
    console.error(error);
  }
}
module.exports = {
  getProductsData,
};
